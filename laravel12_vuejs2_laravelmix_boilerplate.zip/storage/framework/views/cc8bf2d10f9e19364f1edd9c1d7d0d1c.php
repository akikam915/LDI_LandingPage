<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Styles / Scripts -->
    </head>
    <body>
        <div id="app">
            <example-component></example-component>
            
        </div>
    </body>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
</html>
<?php /**PATH C:\laragon\www\test12\resources\views/welcome.blade.php ENDPATH**/ ?>